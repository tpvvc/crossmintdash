import { json, badRequest } from "../utils/helpers.js";
import { createCollection } from "../utils/crossmint.js";

/** @param {Request} request @param {any} env @param {DB} db */
export async function handleCollections(request, env, db) {
  if (request.method === "GET") {
    const rows = await db.all("SELECT * FROM collections ORDER BY id DESC");
    return json({ collections: rows });
  }

  if (request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const { name, chain = "polygon", metadata_uri, created_by_creator_id } = body;
    if (!name) return badRequest("Missing name");

    // Call Crossmint to create collection (optional; you can skip and store only locally)
    const cm = await createCollection(env, { name, chain, metadataUri: metadata_uri });
    const cmId = cm?.id || cm?.collection?.id || null;

    await db.run(
      "INSERT INTO collections (crossmint_collection_id, name, chain, metadata_uri, created_by_creator_id) VALUES (?, ?, ?, ?, ?)",
      [cmId, name, chain, metadata_uri || null, created_by_creator_id || null]
    );

    const rec = await db.get("SELECT * FROM collections WHERE id = last_insert_rowid()");
    return json({ collection: rec, crossmint: cm }, 201);
  }

  return new Response(null, { status: 405, headers: { allow: "GET, POST" } });
}
