import { json, badRequest } from "../utils/helpers.js";

/** @param {Request} request @param {any} env @param {DB} db */
export async function handleCreators(request, env, db) {
  if (request.method === "GET") {
    const rows = await db.all("SELECT * FROM creators ORDER BY id DESC");
    return json({ creators: rows });
  }

  if (request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const { username, display_name, wallet_address, vendor_id } = body;
    if (!username || !display_name) return badRequest("Missing username or display_name");

    await db.run(
      "INSERT INTO creators (username, display_name, wallet_address, vendor_id) VALUES (?, ?, ?, ?)",
      [username, display_name, wallet_address || null, vendor_id || null]
    );
    const rec = await db.get("SELECT * FROM creators WHERE id = last_insert_rowid()");
    return json({ creator: rec }, 201);
  }

  return new Response(null, { status: 405, headers: { allow: "GET, POST" } });
}
