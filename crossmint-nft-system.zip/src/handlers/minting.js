import { json, badRequest } from "../utils/helpers.js";
import { mintTo } from "../utils/crossmint.js";

/** @param {Request} request @param {any} env @param {DB} db */
export async function handleMinting(request, env, db) {
  if (request.method !== "POST") {
    return new Response(null, { status: 405, headers: { allow: "POST" } });
  }
  const body = await request.json().catch(() => ({}));
  const { collection_id, recipient, quantity = 1, metadata = {} } = body;
  if (!collection_id || !recipient) return badRequest("Missing collection_id or recipient");

  // Load Crossmint collection id if we stored a local numeric id
  let collectionId = collection_id;
  if (/^\d+$/.test(String(collection_id))) {
    const row = await db.get("SELECT crossmint_collection_id FROM collections WHERE id = ?", [collection_id]);
    collectionId = row?.crossmint_collection_id || collection_id;
  }

  const res = await mintTo(env, { collectionId, recipient, quantity, metadata }).catch(e => ({ error: e.message }));

  await db.run(
    "INSERT INTO mints (collection_id, recipient, quantity, status, crossmint_request_id) VALUES (?, ?, ?, ?, ?)",
    [collection_id, recipient, quantity, res?.error ? "error" : "submitted", res?.id || null]
  );

  return json({ mint: res });
}
