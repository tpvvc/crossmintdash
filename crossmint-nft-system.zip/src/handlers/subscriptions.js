import { json, badRequest } from "../utils/helpers.js";

/** @param {Request} request @param {any} env @param {DB} db */
export async function handleSubscriptions(request, env, db) {
  if (request.method === "GET") {
    const q = new URL(request.url).searchParams;
    const creator = q.get("creator");
    const sql = creator ?
      "SELECT * FROM subscriptions WHERE creator_id = ? ORDER BY id DESC" :
      "SELECT * FROM subscriptions ORDER BY id DESC";
    const rows = await (creator ? db.all(sql, [creator]) : db.all(sql));
    return json({ subscriptions: rows });
  }

  if (request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const { creator_id, subscriber, plan, status = "active", expires_at = null } = body;
    if (!creator_id || !subscriber || !plan) return badRequest("Missing fields");

    await db.run(
      "INSERT INTO subscriptions (creator_id, subscriber, plan, status, expires_at) VALUES (?, ?, ?, ?, ?)",
      [creator_id, subscriber, plan, status, expires_at]
    );
    const rec = await db.get("SELECT * FROM subscriptions WHERE id = last_insert_rowid()");
    return json({ subscription: rec }, 201);
  }

  return new Response(null, { status: 405, headers: { allow: "GET, POST" } });
}
