import { json, badRequest } from "../utils/helpers.js";

/** @param {Request} request @param {any} env @param {DB} db */
export async function handleVendors(request, env, db) {
  if (request.method === "GET") {
    const rows = await db.all("SELECT * FROM vendors ORDER BY id DESC");
    return json({ vendors: rows });
  }

  if (request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const { slug, display_name, payout_address } = body;
    if (!slug || !display_name) return badRequest("Missing slug or display_name");

    await db.run(
      "INSERT INTO vendors (slug, display_name, payout_address) VALUES (?, ?, ?)",
      [slug, display_name, payout_address || null]
    );
    const rec = await db.get("SELECT * FROM vendors WHERE id = last_insert_rowid()");
    return json({ vendor: rec }, 201);
  }

  return new Response(null, { status: 405, headers: { allow: "GET, POST" } });
}
