import { json, notFound, methodNotAllowed, unauthorized, requireServiceAuth } from "./utils/helpers.js";
import { DB } from "./utils/database.js";
import { handleCollections } from "./handlers/collections.js";
import { handleVendors } from "./handlers/vendors.js";
import { handleCreators } from "./handlers/creators.js";
import { handleSubscriptions } from "./handlers/subscriptions.js";
import { handleMinting } from "./handlers/minting.js";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const db = new DB(env.TOIAF_DB);

    // Simple auth gate for mutating routes if SERVICE_AUTH_TOKEN is set
    if (["POST","PUT","PATCH","DELETE"].includes(request.method)) {
      try { await requireServiceAuth(request, env); } 
      catch { return unauthorized(); }
    }

    if (url.pathname === "/") {
      return json({ ok: true, name: "crossmint-nft-system", time: new Date().toISOString() });
    }

    if (url.pathname.startsWith("/api/collections")) {
      return handleCollections(request, env, db);
    }

    if (url.pathname.startsWith("/api/vendors")) {
      return handleVendors(request, env, db);
    }

    if (url.pathname.startsWith("/api/creators")) {
      return handleCreators(request, env, db);
    }

    if (url.pathname.startsWith("/api/subscriptions")) {
      return handleSubscriptions(request, env, db);
    }

    if (url.pathname.startsWith("/api/mint")) {
      return handleMinting(request, env, db);
    }

    return notFound();
  }
}
