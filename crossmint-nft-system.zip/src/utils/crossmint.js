/**
 * Thin wrapper for Crossmint API.
 * Provide env.CROSSMINT_PROJECT_ID and set env.CROSSMINT_CLIENT_SECRET via `wrangler secret`.
 */

const DEFAULT_BASE = "https://www.crossmint.com/api";

function authHeaders(env) {
  if (!env.CROSSMINT_PROJECT_ID) throw new Error("CROSSMINT_PROJECT_ID missing");
  if (!env.CROSSMINT_CLIENT_SECRET) throw new Error("CROSSMINT_CLIENT_SECRET missing");
  return {
    "x-client-secret": env.CROSSMINT_CLIENT_SECRET,
    "x-project-id": env.CROSSMINT_PROJECT_ID,
    "content-type": "application/json"
  };
}

export async function cmFetch(env, path, init = {}) {
  const base = env.CROSSMINT_API_BASE || DEFAULT_BASE;
  const url = base.replace(/\/$/, "") + path;
  const res = await fetch(url, { ...init, headers: { ...(init.headers || {}), ...authHeaders(env) }});
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Crossmint ${res.status}: ${txt}`);
  }
  return res.json();
}

export async function createCollection(env, { name, chain = "polygon", metadataUri }) {
  return cmFetch(env, "/2022-06-09/collections", {
    method: "POST",
    body: JSON.stringify({ chain, name, metadataUri })
  });
}

export async function mintTo(env, { collectionId, recipient, quantity = 1, metadata }) {
  return cmFetch(env, `/2022-06-09/collections/${collectionId}/nfts`, {
    method: "POST",
    body: JSON.stringify({ recipient, metadata, quantity })
  });
}
