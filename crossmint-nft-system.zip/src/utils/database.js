export class DB {
  /** @param {D1Database} d1 */
  constructor(d1) {
    this.d1 = d1;
  }

  async all(sql, bind = []) {
    const res = await this.d1.prepare(sql).bind(...bind).all();
    return res.results || [];
  }

  async get(sql, bind = []) {
    const res = await this.d1.prepare(sql).bind(...bind).first();
    return res || null;
  }

  async run(sql, bind = []) {
    const res = await this.d1.prepare(sql).bind(...bind).run();
    return res;
  }
}
