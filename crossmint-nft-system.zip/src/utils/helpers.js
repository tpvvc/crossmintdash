export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers },
  });
}

export function badRequest(message = "Bad Request") {
  return json({ error: message }, 400);
}

export function unauthorized(message = "Unauthorized") {
  return json({ error: message }, 401, { "WWW-Authenticate": "Bearer" });
}

export function notFound(message = "Not Found") {
  return json({ error: message }, 404);
}

export function methodNotAllowed(allow = "GET") {
  return new Response(null, { status: 405, headers: { allow: allow } });
}

export async function requireServiceAuth(request, env) {
  const hdr = request.headers.get("authorization") || "";
  const token = hdr.startsWith("Bearer ") ? hdr.slice(7) : "";
  if (!env.SERVICE_AUTH_TOKEN) return true; // if unset, skip
  if (token !== env.SERVICE_AUTH_TOKEN) throw new Error("unauthorized");
  return true;
}

export function qs(url) {
  return Object.fromEntries(new URL(url).searchParams.entries());
}
